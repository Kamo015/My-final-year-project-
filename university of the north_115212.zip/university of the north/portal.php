﻿<?php
// Start session
session_start();

// Check if the student is logged in
if (!isset($_SESSION['student_number'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Include database connection file
require 'database.php';

// Get the student number from the session
$student_number = $_SESSION['student_number'];

$sql = "SELECT student_number, program_name FROM students WHERE student_number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_number);
$stmt->execute();
$result = $stmt->get_result();

// Fetch user data
$user = $result->fetch_assoc();
$program = $user ? $user['program_name'] : "Not registered for any program";
// Check if the student has a registered program
$program = $result->fetch_assoc();

$stmt->close();
$conn->close();
?></html>

﻿<?php
// Start session
session_start();

// Include the database connection
require 'database.php';  // Update with your actual database connection file path

// Initialize an error message variable
$error_message = '';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $student_number = trim($_POST['student_number']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (!empty($student_number) && !empty($password)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the student number already exists
        $checkQuery = "SELECT * FROM password WHERE student_number = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("s", $student_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            // Insert new record into the password table
            $query = "INSERT INTO password (student_number, hashed_password) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $student_number, $hashed_password);

            if ($stmt->execute()) {
                // Registration successful, redirect to login page
                header("Location: portal.html");
                exit();
            } else {
                $error_message = "Error storing your account details. Please try again.";
            }
        } else {
            $error_message = "Student number already exists. Please try a different number.";
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    } else {
        $error_message = "Please fill in all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .registration-form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .registration-form h2 {
            margin-bottom: 15px;
            color: #333;
        }

        .registration-form label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        .registration-form input[type="text"],
        .registration-form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .registration-form button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        .registration-form button:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <form class="registration-form" action="register new account.php" method="POST"> <!-- Replace 'your_php_file.php' with the name of your PHP file -->
        <h2>Student Registration</h2>
        <?php if (!empty($error_message)) : ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <label for="student_number">Student Number:</label>
        <input type="text" id="student_number" name="student_number" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Register</button>
    </form>
</body>
</html>

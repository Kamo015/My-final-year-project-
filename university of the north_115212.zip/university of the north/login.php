﻿<?php
// Database connection parameters
$servername = "localhost";
$username = "root";  // Use your MySQL username
$password = "";      // Use your MySQL password
$dbname = "university";  // Use your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user = 'student_number';
$program = '';

// Query to fetch data from the student table (adjust according to your table schema)
$sql = "SELECT student_number, program FROM students LIMIT 1"; // Adjust WHERE clause or other criteria as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user = htmlspecialchars($row['student_number']);
    $program = htmlspecialchars($row['program']);
} else {
    $user = 'N/A';
    $program = 'N/A';
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="university.css">
    <title>Student Portal</title>
    <style>
        /* Styles here */
    </style>
</head>
<body style="background-image: url('/university/logo.png.webp');
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-blend-mode: multiply; /* Darkens the background image */
    background-color: rgba(0, 0, 0, 0.7);
    ">
    <header style="color: white;">
        <h1>Welcome to the Student Portal</h1>
        <p>Hello, Student Number: <?php echo $user; ?></p>
        <p>Your Registered Program: <?php echo $program; ?></p>
    </header>
    <main>
        <!-- Announcements, Events Calendar, Social Media, etc. -->
        <div class="announcements">
            <h2  style="color: white;">Announcements</h2>
            <ul  style="color: white;">
                <li>Final exams start on December 10th.</li>
                <li>Registration for Spring semester opens on November 20th.</li>
                <li>Join us for the Career Fair on November 30th!</li>
            </ul>
        </div>

        <div class="events-calendar">
            <h2  style="color: white;">Upcoming Events</h2>
            <ul  style="color: white;">
                <li><strong>November 15, 2024:</strong> Workshop on Time Management - 3 PM to 5 PM</li>
                <li><strong>November 20, 2024:</strong> Guest Lecture: Innovations in Technology - 1 PM</li>
                <li><strong>November 25, 2024:</strong> Career Fair - 10 AM to 4 PM</li>
                <li><strong>December 1, 2024:</strong> Study Skills Seminar - 2 PM to 4 PM</li>
                <li><strong>December 5, 2024:</strong> End-of-Semester Celebration - 6 PM</li>
            </ul>
        </div>

        <div class="social-media-integration">
            <h2  style="color: white;">Connect Your Social Media</h2>
            <p style="color: white;">Link your social media accounts to share your achievements and events with your friends!</p>
            <form>
                <label for="facebook">Facebook:</label>
                <input type="url" id="facebook" name="facebook" placeholder="https://facebook.com/University_Of_The_North">

                <label for="twitter">Twitter:</label>
                <input type="url" id="twitter" name="twitter" placeholder="https://twitter.com/University_Of_The_North">

                <label for="instagram">Instagram:</label>
                <input type="url" id="instagram" name="instagram" placeholder="https://instagram.com/University_Of_The_North">

                <label for="linkedin">LinkedIn:</label>
                <input type="url" id="linkedin" name="linkedin" placeholder="https://linkedin.com/in/University_Of_The_North">

                <button type="submit">Save Links</button>
            </form>
        </div>
    </main>
    <footer>
        <p>© 2024 Student Portal</p>
    </footer>
</body>
</html>

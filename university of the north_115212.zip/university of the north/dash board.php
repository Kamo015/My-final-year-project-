﻿<?php
// Start session
session_start();

// Include database connection file
require 'database.php';

// Initialize error message
$error_message = '';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_number = trim($_POST['student_number']);
    $password = trim($_POST['password']);

    if (!empty($student_number) && !empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the student number already exists
        $stmt = $conn->prepare("SELECT * FROM students WHERE student_number = ?");
        $stmt->bind_param("s", $student_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            // Insert new student record into the database
            $stmt = $conn->prepare("INSERT INTO students (student_number, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $student_number, $hashed_password);

            if ($stmt->execute()) {
                // Registration successful, redirect to login page
                header("Location: login.php");
                exit();
            } else {
                $error_message = "Error creating account. Please try again.";
            }
        } else {
            $error_message = "Student number already exists. Please try a different number.";
        }

        $stmt->close();
    } else {
        $error_message = "Please fill in all fields.";
    }
}
?>

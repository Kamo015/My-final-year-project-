<?php
// Database connection parameters
$servername = "localhost";
$username = "root";  // Use your MySQL username
$password = "";      // Use your MySQL password
$dbname = "university";  // Use your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to generate a unique student number
function generateStudentNumber() {
    $year = date("Y"); // Current year
    $uniqueNumber = str_pad(mt_rand(0, 9999), 4, '0', STR_PAD_LEFT); // Random 4-digit number
    return "UN-$year-$uniqueNumber";
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize inputs
    $firstName = htmlspecialchars(trim($_POST['firstName']));
    $lastName = htmlspecialchars(trim($_POST['lastName']));
    $idNumber = htmlspecialchars(trim($_POST['idNumber']));
    $dob = $_POST['dob'];
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = htmlspecialchars(trim($_POST['phone']));
    $address = htmlspecialchars(trim($_POST['address']));
    $highschool = htmlspecialchars(trim($_POST['highschool']));

    // Generate a unique student number
    $studentNumber = generateStudentNumber();

    // Prepare the SQL statement (fixed the query syntax here)
    $sql = "INSERT INTO application (first_name, last_name, id_number, dob, email, phone, address, highschool, student_number) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Initialize and execute prepared statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $firstName, $lastName, $idNumber, $dob, $email, $phone, $address, $highschool, $studentNumber);

    if ($stmt->execute()) {
        // Success message
        echo "<h2>Application Submitted Successfully!</h2>";
        echo "<p>Your student number is: <strong>$studentNumber</strong>.</p>";
        echo "<p>Thank you, $firstName $lastName, for your application.</p>";
    } else {
        // Error message
        echo "<h3>Error: " . $stmt->error . "</h3>";
    }

    // Close statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty of Law</title>
    <link rel="stylesheet" href="university.css">
</head>
<body style="background-image: url('/university/logo.png.webp');
		background-size: cover;
		background-repeat: no-repeat;
		background-attachment: fixed;
		background-blend-mode: multiply; /* Darkens the background image */
		background-color: rgba(0, 0, 0, 0.7);
		">

        <h2 style="color: white;">About Us</h2>
        <p style="color: white;">We are a leading  university providing world-class education and research opportunities.</p>
    </section>
    <footer>
<p>&copy; 2024 University of the north. All rights reserved.</p>    </footer>
</body>
</html>
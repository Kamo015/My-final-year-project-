<?php
// Database configuration
// Database connection parameters
$servername = "localhost";
$username = "root";  // Use your MySQL username
$password = "";      // Use your MySQL password
$dbname = "university";  // Use your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect and sanitize POST data
$cardname = $conn->real_escape_string($_POST['card_name']);
$cardNumber = $conn->real_escape_string($_POST['card_number']);
$expiryDate = $conn->real_escape_string($_POST['expiryDate']);
$cvv = $conn->real_escape_string($_POST['cvv']);
$reference = $conn->real_escape_string($_POST['reference']);
$amount = $conn->real_escape_string($_POST['amount']);

// Insert data into the database
$sql = "INSERT INTO payments (card_name, card_number, expiry_date, cvv, reference, amount) 
        VALUES ('$cardname', '$cardNumber', '$expiryDate', '$cvv', '$reference', '$amount')";

if ($conn->query($sql) === TRUE) {
    echo "Payment successfully recorded.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>

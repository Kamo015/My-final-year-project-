<?php
// Configuration
$db_host = 'localhost';
$db_username = "root";
$db_password = "";
$db_name = 'university_db';

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get form data
  $course_name = $_POST['course_name'];
  $course_description = $_POST['course_description'];
  $duration = $_POST['duration'];
  $eligibility = $_POST['eligibility'];

  // Insert data into courses table
  $sql = "INSERT INTO courses (course_name, course_description, duration, eligibility) VALUES ('$course_name', '$course_description', '$duration', '$eligibility')";

  if ($conn->query($sql) === TRUE) {
    echo "New course inserted successfully!";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close connection
$conn->close();
?>

<!-- HTML Form -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <label for="course_name">Course Name:</label>
  <input type="text" id="course_name" name="course_name"><br><br>
  <label for="course_description">Course Description:</label>
  <textarea id="course_description" name="course_description"></textarea><br><br>
  <label for="duration">Duration:</label>
  <input type="text" id="duration" name="duration"><br><br>
  <label for="eligibility">Eligibility:</label>
  <input type="text" id="eligibility" name="eligibility"><br><br>
  <input type="submit" value="Insert Course">
</form>
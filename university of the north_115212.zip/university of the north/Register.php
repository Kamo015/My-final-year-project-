<?php 
// Database connection parameters
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "university"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $studentNumber = htmlspecialchars(trim($_POST['studentNumber']));
    $firstName = htmlspecialchars(trim($_POST['firstName']));
    $program = htmlspecialchars(trim($_POST['courses'])); // 'courses' corresponds to the select name in HTML

    // Check if the student number exists in the application table
    $sql = "SELECT * FROM application WHERE student_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $studentNumber);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Student number exists, store student information in the students table
        $insertSql = "INSERT INTO students (student_number, first_name, program) VALUES (?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("sss", $studentNumber, $firstName, $program);

        if ($insertStmt->execute()) {
            // Registration successful
            echo "<h3>Registration Successful!</h3>";
            echo "<p>Student Number: " . htmlspecialchars($studentNumber) . "</p>";
            echo "<p>First Name: " . htmlspecialchars($firstName) . "</p>";
            echo "<p>Selected Program: " . htmlspecialchars($program) . "</p>";
        } else {
            echo "<h3>Error: " . $insertStmt->error . "</h3>";
        }
        
        // Close the insert statement
        $insertStmt->close();
    } else {
        // Student number does not exist in the application table
        echo "<h3>Error: Invalid Student Number</h3>";
        echo "<p>The student number you entered does not exist in the application table.</p>";
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty of Law</title>
    <link rel="stylesheet" href="university.css">
</head>
<body style="background-image: url('/university/logo.png.webp');
		background-size: cover;
		background-repeat: no-repeat;
		background-attachment: fixed;
		background-blend-mode: multiply; /* Darkens the background image */
		background-color: rgba(0, 0, 0, 0.7);
		">>

        <h2 style="color: white;">About Us</h2>
        <p style="color: white;">We are a leading  university providing world-class education and research opportunities.</p>
    </section>
    <footer>
<p>&copy; 2024 University of the north. All rights reserved.</p>    </footer>
</body>
</html>
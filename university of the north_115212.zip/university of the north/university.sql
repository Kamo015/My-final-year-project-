-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2024 at 10:45 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `id_number` int(14) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(20) NOT NULL,
  `address` text NOT NULL,
  `program` varchar(100) NOT NULL,
  `highschool` varchar(100) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `first_name`, `last_name`, `id_number`, `dob`, `email`, `phone`, `address`, `program`, `highschool`, `student_number`, `application_date`, `password`) VALUES
(10, 'Amon', 'Moloise', 2147483647, '2002-08-28', 'amonmoloise6@gmail.com', 767160230, '170 Bendor Drive\r\nBendor Ext 44', '', 'pax', 'UN-2024-9016', '2024-11-15 12:55:36', ''),
(11, 'kgothatso', 'mashashane', 2147483647, '2001-12-09', 'ckgothatso@gmail.com', 124464899, '45 RISSIK', '', 'NORTH EAST', 'UN-2024-3806', '2024-11-15 13:10:20', ''),
(12, 'kamogelo', 'rasesemola', 2147483647, '1998-09-18', 'kmoletoaba@gmail.com', 727585821, '170 Bendor Drive\r\nBendor Ext 44', '', 'mohlakaneng secondary', 'UN-2024-9393', '2024-11-18 11:00:14', '');

-- --------------------------------------------------------

--
-- Table structure for table `password`
--

CREATE TABLE `password` (
  `student_number` int(11) NOT NULL,
  `hashed_password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password`
--

INSERT INTO `password` (`student_number`, `hashed_password`) VALUES
(0, '$2y$10$zUIj841/aUqI14ptIA');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `card_name` varchar(100) NOT NULL,
  `card_number` int(80) NOT NULL,
  `expiry_date` date NOT NULL,
  `cvv` varchar(3) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `card_name`, `card_number`, `expiry_date`, `cvv`, `reference`, `amount`, `created_at`) VALUES
(4, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:25:59'),
(5, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:26:56'),
(6, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:27:34'),
(7, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:29:39'),
(8, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:30:05'),
(9, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:31:12'),
(10, '', 0, '0000-00-00', '', '', '0.00', '2024-11-06 11:34:36');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_number` int(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `program` varchar(100) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_number`, `first_name`, `program`, `password`) VALUES
(2, 'Amon', 'anatomy', '1234'),
(3, 'kamogelo', 'anatomy', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_number` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

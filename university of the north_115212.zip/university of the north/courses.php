<?php
include 'db_connect.php';

$sql = "SELECT * FROM courses";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses</title>
    <link rel="stylesheet" href="university.css">
</head>
<body>
    <header>
        <h1>Our Courses</h1>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="faculty.php">Faculty</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <h2>Available Courses</h2>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div>";
                echo "<h3>" . $row["course_name"] . "</h3>";
                echo "<p>" . $row["course_description"] . "</p>";
                echo "<p><strong>Duration:</strong> " . $row["duration"] . "</p>";
                echo "<p><strong>Eligibility:</strong> " . $row["eligibility"] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No courses available.</p>";
        }
        ?>
    </section>
    <footer>
       <p>&copy; 2024 University of the north. All rights reserved.</p>
    </footer>
</body>
</html>
